import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Inventory controller class, provides functionality to the inventory window on a base Inventory object.
 * @author Steven Barton
 */
public class InventoryController {

    Inventory inv;

    @FXML // fx:id="mainLabel"
    private Label mainLabel; // Value injected by FXMLLoader

    @FXML // fx:id="exitButton"
    private Button exitButton; // Value injected by FXMLLoader

    @FXML // fx:id="partsPane"
    private Pane partsPane; // Value injected by FXMLLoader

    @FXML // fx:id="partsPaneLabel"
    private Label partsPaneLabel; // Value injected by FXMLLoader

    @FXML // fx:id="partsSearchField"
    private TextField partsSearchField; // Value injected by FXMLLoader

    @FXML // fx:id="partsTable"
    private TableView<Part> partsTable; // Value injected by FXMLLoader

    @FXML // fx:id="partIdColumn"
    private TableColumn<Part, Integer> partIdColumn; // Value injected by FXMLLoader

    @FXML // fx:id="partNameColumn"
    private TableColumn<Part, String> partNameColumn; // Value injected by FXMLLoader

    @FXML // fx:id="partInventoryColumn"
    private TableColumn<Part, Integer> partInventoryColumn; // Value injected by FXMLLoader

    @FXML // fx:id="partPriceColumn"
    private TableColumn<Part, Double> partPriceColumn; // Value injected by FXMLLoader

    @FXML // fx:id="addPartsButton"
    private Button addPartsButton; // Value injected by FXMLLoader

    @FXML // fx:id="modifyPartsButton"
    private Button modifyPartsButton; // Value injected by FXMLLoader

    @FXML // fx:id="deletePartsButton"
    private Button deletePartsButton; // Value injected by FXMLLoader

    @FXML // fx:id="productsPane"
    private Pane productsPane; // Value injected by FXMLLoader

    @FXML // fx:id="productsPaneLabel"
    private Label productsPaneLabel; // Value injected by FXMLLoader

    @FXML // fx:id="productsSearchField"
    private TextField productsSearchField; // Value injected by FXMLLoader

    @FXML // fx:id="productsTable"
    private TableView<Product> productsTable; // Value injected by FXMLLoader

    @FXML // fx:id="productIdColumn"
    private TableColumn<Product, Integer> productIdColumn; // Value injected by FXMLLoader

    @FXML // fx:id="productNameColumn"
    private TableColumn<Product, String> productNameColumn; // Value injected by FXMLLoader

    @FXML // fx:id="productInventoryColumn"
    private TableColumn<Product, Integer> productInventoryColumn; // Value injected by FXMLLoader

    @FXML // fx:id="productPriceColumn"
    private TableColumn<Product, Double> productPriceColumn; // Value injected by FXMLLoader

    @FXML // fx:id="addProductsButton"
    private Button addProductsButton; // Value injected by FXMLLoader

    @FXML // fx:id="modifyProductsButton"
    private Button modifyProductsButton; // Value injected by FXMLLoader

    @FXML // fx:id="deleteProductsButton"
    private Button deleteProductsButton; // Value injected by FXMLLoader

    @FXML
    private Label errorMessage;

    @FXML
    private Label productConfirmMessage;

    @FXML
    private Label partConfirmMessage;

    /**
     * Initialize method for the inventory controller, initializes the Inventory object, sets up and loads data to the
     * tableView.
     */
    public void initialize() {
        inv = new Inventory();

        errorMessage.setVisible(false);
        partConfirmMessage.setVisible(false);
        productConfirmMessage.setVisible(false);

        inv.addPart(new Outsourced(inv.getPartIdNum(), "Handle", 44.99, 10, 1, 40, "Duratec"));
        inv.addPart(new InHouse(inv.getPartIdNum(), "Knob", 12.88, 12, 1, 50, 234));
        inv.addPart(new InHouse(inv.getPartIdNum(), "Dial", 5.99, 30, 1, 80, 336));
        inv.addPart(new Outsourced(inv.getPartIdNum(), "Screen", 98.55, 4, 1, 15, "Dell"));
        inv.addPart(new InHouse(inv.getPartIdNum(), "Keyboard", 44.87, 5, 1, 20, 377));

        inv.addProduct(new Product(inv.getProdIdNum(), "Computation Master", 599.99, 3, 1, 13));
        inv.addProduct(new Product(inv.getProdIdNum(), "Gaming Machine-O", 999.99, 4, 1, 6));

        // Set up the columns for the partTable tableView.
        partIdColumn.setCellValueFactory(new PropertyValueFactory<Part, Integer>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
        partInventoryColumn.setCellValueFactory(new PropertyValueFactory<Part, Integer>("stock"));
        partPriceColumn.setCellValueFactory(new PropertyValueFactory<Part, Double>("price"));

        // Set up the columns for the productTable tableView.
        productIdColumn.setCellValueFactory(new PropertyValueFactory<Product, Integer>("id"));
        productNameColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("name"));
        productInventoryColumn.setCellValueFactory(new PropertyValueFactory<Product, Integer>("stock"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<Product, Double>("price"));

        // load data
        load();
    }

    /**
     * Exit button listener, closes the application.
     */
    public void exitButtonListener() {
        Platform.exit();
    }

    /**
     * Listener for the parts search bar allowing searches.  If a part number is input that part is selected.  If a
     * string of characters is input, a search is completed using that string and the list is filtered.
     */
    public void partSearchBarListener() {
        partsSearchField.setOnKeyReleased(event -> {

            errorMessage.setVisible(false);
            partConfirmMessage.setVisible(false);
            productConfirmMessage.setVisible(false);

            String input = partsSearchField.getText();
            boolean isInt = NumberChecker.isInteger(input);

            if(input.length() >= 1 && isInt) {
                // Perform a search of parts based on part ID
                ObservableList<Part> result = FXCollections.observableArrayList();

                try {
                    int idSearch = Integer.parseInt(input);
                    result.add(inv.lookupPart(idSearch));
                } catch (IOException e) {
                    //e.printStackTrace();
                }

                if(result.size() > 0) {
                    partsTable.getSelectionModel().select(result.get(0));
                }
                // partsTable.setItems(result);
            }
            else {
                // Perform a search of parts based on a String
                partsTable.setItems(inv.lookupPart(input));
            }
        });
    }

    /**
     * Listener for the products search bar allowing searches.  If a product number is input that product is selected.
     * If a string of characters is input, a search is completed using that string and the list is filtered.
     */
    public void productSearchBarListener() {
        productsSearchField.setOnKeyReleased(event -> {

            errorMessage.setVisible(false);
            partConfirmMessage.setVisible(false);
            productConfirmMessage.setVisible(false);

            String input = productsSearchField.getText();
            boolean isInt = NumberChecker.isInteger(input);

            if(input.length() >= 1 && isInt) {
                // Perform a search of products based on product ID
                ObservableList<Product> result = FXCollections.observableArrayList();

                try {
                    int idSearch = Integer.parseInt(input);
                    result.add(inv.lookupProduct(idSearch));
                } catch (IOException e) {
                    //e.printStackTrace();
                }

                if(result.size() > 0) {
                    productsTable.getSelectionModel().select(result.get(0));
                }

                // productsTable.setItems(result);
            }
            else {
                // Perform a search of products based on a String
                productsTable.setItems(inv.lookupProduct(input));
            }
        });
    }

    /**
     * Listener to capture input into the add part button.  Loads and initializes the add part window from FXML.
     */
    public void partsAddButtonListener() {
        addPartsButton.setOnMouseClicked(event -> {

            errorMessage.setVisible(false);
            partConfirmMessage.setVisible(false);
            productConfirmMessage.setVisible(false);

            Stage addPart = new Stage();

            Parent parent = null;

            FXMLLoader loader = null;

            try {
                loader = new FXMLLoader(getClass().getResource("AddPart.fxml"));
                //parent = FXMLLoader.load(getClass().getResource("AddPart.fxml"));
                parent = loader.load();
            }
            catch (Exception e) {
                //
            }

            assert parent != null;
            Scene scene = new Scene(parent);

            AddPartController addPartController = loader.getController();

            // Now access methods for addPartController to pass data.
            addPartController.getInventoryController(this);

            addPart.setTitle("Add Part");

            addPart.setScene(scene);

            //addPart.initModality(Modality.WINDOW_MODAL);
            //addPart.initOwner(inv.getStage());

            addPart.show();

        });
    }

    /**
     * Listener to capture input into the update part button.  Loads and initializes the update part window from FXML.
     *
     * RUNTIME ERROR: This method generated a NullPointerException when initiating the Stage object.  I had to assign
     * the controller here instead of in the FXML file in order to be able to pass data between this controller and the
     * ModifyPartController object.  When I tried to work with the inventory in ModifyPartController.Initialize() method
     * I was getting the NullPointerException due to a null parent object.  Initiating and assigning the controller here
     * allows me to pass this object to the update parts window controller and then be able to ass data back and forth
     * between the controllers. This same method was used for the update product window.
     */
    public void partsUpdateButtonListener () {
       modifyPartsButton.setOnMouseClicked(event -> {

           errorMessage.setVisible(false);
           partConfirmMessage.setVisible(false);
           productConfirmMessage.setVisible(false);

           modifyPartsButton.setStyle("-fx-text-inner-color: black;");

           if(partsTable.getSelectionModel().getSelectedItem() == null) {
               modifyPartsButton.setStyle("-fx-text-inner-color: red;");
           }
           else {
               modifyPartsButton.setStyle("-fx-text-inner-color: black;");

               Part getPart = partsTable.getSelectionModel().getSelectedItem();

               Stage stage = new Stage();

               FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("ModifyPart.fxml"));

               ModifyPartController controller = new ModifyPartController();

               controller.setPart(getPart);

               controller.setInventoryController(this);

               loader.setController(controller);

               Parent parent = null;

               try {
                   parent = loader.load();
               } catch (IOException e) {
                   //
               }

               Scene scene = new Scene(parent);

               stage.setTitle("Modify Part");

               stage.setScene(scene);

               stage.show();
           }
       });
    }

    /**
     * Listener to capture input into the delete part button.  Removes the selected part from the inventory.
     */
    public void partsDeleteButtonListener() {
        deletePartsButton.setOnMouseClicked(event -> {

            errorMessage.setVisible(false);
            partConfirmMessage.setVisible(false);
            productConfirmMessage.setVisible(false);

            if(partsTable.getSelectionModel().getSelectedItem() == null) {

            }
            else {
                inv.deletePart(partsTable.getSelectionModel().getSelectedItem());

                partsTable.setItems(inv.getAllParts());

                partConfirmMessage.setText("SUCCESS: Part Deleted!");
                partConfirmMessage.setVisible(true);
            }
        });
    }

    /**
     * Listener to capture input into the add product button. Loads and initializes the add product window from FXML.
     */
    public void prodAddButtonListener () {
        addProductsButton.setOnMouseClicked(event -> {

            errorMessage.setVisible(false);
            partConfirmMessage.setVisible(false);
            productConfirmMessage.setVisible(false);

            Stage addProd = new Stage();

            Parent parent = null;

            FXMLLoader loader = null;

            try {
                loader = new FXMLLoader(getClass().getResource("AddProduct.fxml"));
                //parent = FXMLLoader.load(getClass().getResource("AddPart.fxml"));
                parent = loader.load();
            }
            catch (Exception e) {
                //
            }

            assert loader != null;
            AddProductController addProdController = loader.getController();

            addProdController.getInventoryController(this);

            addProdController.setItems(inv);

            assert parent != null;
            Scene scene = new Scene(parent);

            addProd.setTitle("Add Product");

            addProd.setScene(scene);

            addProd.show();

        });
    }

    /**
     * Listener to capture input into the update product button. Loads and initializes the update product window
     * from FXML.
     */
    public void prodUpdateButtonListener () {
        modifyProductsButton.setOnMouseClicked(event -> {

            errorMessage.setVisible(false);
            partConfirmMessage.setVisible(false);
            productConfirmMessage.setVisible(false);

            modifyProductsButton.setStyle("-fx-text-inner-color: black;");

            if(productsTable.getSelectionModel().getSelectedItem() == null) {
                modifyProductsButton.setStyle("-fx-text-inner-color: red;");
            }
            else {
                modifyProductsButton.setStyle("-fx-text-inner-color: black;");

                Product getProduct = productsTable.getSelectionModel().getSelectedItem();

                Stage modProd = new Stage();

                Parent parent = null;

                FXMLLoader loader = null;

                try {
                    loader = new FXMLLoader(getClass().getResource("ModifyProduct.fxml"));
                    //parent = FXMLLoader.load(getClass().getResource("AddPart.fxml"));
                    parent = loader.load();
                } catch (Exception e) {
                    //
                }

                ModifyProductController modProdController = loader.getController();

                modProdController.getInventoryController(this);

                modProdController.setProduct(getProduct);

                modProdController.setParts(inv);

                modProdController.setAssociatedParts(getProduct);

                Scene scene = new Scene(parent);

                modProd.setTitle("Modify Product");

                modProd.setScene(scene);

                modProd.show();
            }
        });
    }

    /**
     * Listener to capture input into the delete product button.  Deletes the selected product from the inventory.
     */
    public void prodDeleteButtonListener () {
        deleteProductsButton.setOnMouseClicked(event -> {

            errorMessage.setVisible(false);
            partConfirmMessage.setVisible(false);
            productConfirmMessage.setVisible(false);

            if(productsTable.getSelectionModel().getSelectedItem().getAllAssociatedParts().size() > 0) {
                errorMessage.setText("ERROR: Product has associated parts, cannot delete!");
                errorMessage.setVisible(true);
                return;
            }

            if(productsTable.getSelectionModel().getSelectedItem() == null) {

            }
            else {
                inv.deleteProduct(productsTable.getSelectionModel().getSelectedItem());

                productsTable.setItems(inv.getAllProducts());

                productConfirmMessage.setText("SUCCESS: Product deleted!");
                productConfirmMessage.setVisible(true);
            }
        });
    }

    /**
     * Method to retrieve an instance of the base inventory,
     * @return The base inventory object.
     */
    public Inventory getInventory() {
        return this.inv;
    }

    /**
     * Sorts the inventory to ensure product ID order and then loads items to the parts list.
     */
    public void load() {
        inv.sort();
        partsTable.setItems(inv.getAllParts());
        partsTable.refresh();
        productsTable.setItems(inv.getAllProducts());
        productsTable.refresh();
    }
}

