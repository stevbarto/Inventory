import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Controller class for the modify product window, adds functionality to the FXML generated window.  Imports a Product
 * object to modify.
 */
public class ModifyProductController {

    InventoryController invCtrl;

    Inventory inv;

    Product product;

    Product archiveProduct;

    @FXML
    private Label modProductButton;

    @FXML
    private Label idLabel;

    @FXML
    private Label nameLabel;

    @FXML
    private Label inventoryLabel;

    @FXML
    private Label priceLabel;

    @FXML
    private Label maxLabel;

    @FXML
    private Label minLabel;

    @FXML
    private TextField productIdField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField stockField;

    @FXML
    private TextField priceField;

    @FXML
    private TextField maxField;

    @FXML
    private TextField minField;

    @FXML
    private TextField partsSearchField;

    @FXML
    private TableView<Part> partsTable;

    @FXML
    private TableColumn<Part, Integer> partIdColumn;

    @FXML
    private TableColumn<Part, String> partNameColumn;

    @FXML
    private TableColumn<Part, Integer> partInventoryColumn;

    @FXML
    private TableColumn<Part, Double> partPriceColumn;

    @FXML
    private Button addAssociatedPartButton;

    @FXML
    private Button removeAssociatedPartButton;

    @FXML
    private Button saveProductButton;

    @FXML
    private Button cancelProductButton;

    @FXML
    private TableView<Part> associatedPartsTable;

    @FXML
    private TableColumn<Part, Integer> partIdColumn1;

    @FXML
    private TableColumn<Part, String> partNameColumn1;

    @FXML
    private TableColumn<Part, Integer> partInventoryColumn1;

    @FXML
    private TableColumn<Part, Double> partPriceColumn1;

    @FXML
    private Label errorMessage;

    @FXML
    private Label confirmLabel;

    /**
     * Method to initialize the ModifyProductController object.  Sets listeners for the controls and sets initial values.
     */
    public void initialize() {
        nameField.setOnAction(e -> productNameFieldListener());

        stockField.setOnAction(e -> productInventoryFieldListener());

        priceField.setOnAction(e -> productPriceFieldListener());

        maxField.setOnAction(e -> productMaxFieldListener());

        minField.setOnAction(e -> productMinFieldListener());

        partsSearchField.setOnAction(e -> partSearchBarListener());

        addAssociatedPartButton.setOnAction(e -> addAssociatedPartButtonListener());

        removeAssociatedPartButton.setOnAction(e -> removeAssociatedPartButtonListener());

        saveProductButton.setOnAction(e -> saveButtonListener());

        cancelProductButton.setOnAction(e -> cancelButtonListener());

        partIdColumn.setCellValueFactory(new PropertyValueFactory<Part, Integer>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
        partInventoryColumn.setCellValueFactory(new PropertyValueFactory<Part, Integer>("stock"));
        partPriceColumn.setCellValueFactory(new PropertyValueFactory<Part, Double>("price"));

        partIdColumn1.setCellValueFactory(new PropertyValueFactory<Part, Integer>("id"));
        partNameColumn1.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
        partInventoryColumn1.setCellValueFactory(new PropertyValueFactory<Part, Integer>("stock"));
        partPriceColumn1.setCellValueFactory(new PropertyValueFactory<Part, Double>("price"));

    }

    /**
     * Method to get the InventoryController from the launch method in that controller.
     * @param inventoryController Controller instance.
     */
    public void getInventoryController(InventoryController inventoryController) {
        this.invCtrl = inventoryController;
    }

    /**
     * Sets the available parts in the upper parts table.
     * @param inv Inventory instance which holds the parts list.
     */
    public void setParts(Inventory inv) {
        partsTable.setItems(inv.getAllParts());
    }

    /**
     * Sets the associated parts for view on the current product.
     * @param p Product instance to get associated parts list from.
     */
    public void setAssociatedParts(Product p) {
        associatedPartsTable.setItems(p.getAllAssociatedParts());
    }

    /**
     * Sets the inventory instance for the current ModifyProductController instance.
     * @param items Inventory object containing the items for this inventory.
     */
    public void setInventory(Inventory items) {
        inv = items;
    }

    /**
     * Sets the current selected product for this instance.
     * @param p Product object selected in the InventoryController.
     */
    public void setProduct(Product p) {
        this.product = p;

        productIdField.setText(Integer.toString(product.getId()));

        nameField.setText(product.getName());

        stockField.setText(Integer.toString(product.getStock()));

        priceField.setText(Double.toString(product.getPrice()));

        minField.setText(Integer.toString(product.getMin()));

        maxField.setText(Integer.toString(product.getMax()));

        //associatedPartsTable.setItems(product.getAllAssociatedParts());
    }

    /**
     * Listener to capture input to the Name field.  String object for the name of the product.
     */
    public void productNameFieldListener() {
        nameField.setOnKeyReleased(event -> this.product.setName(nameField.getText()));
    }

    /**
     * Listener to capture input to the Inventory field. An int value for the current inventory.
     */
    public void productInventoryFieldListener() {
        stockField.setOnKeyReleased(event -> {

            stockField.setStyle("-fx-text-inner-color: black;");

            if(NumberChecker.isInteger(stockField.getText())) {
                try {
                    this.product.setStock(Integer.parseInt(stockField.getText()));
                }
                catch (NumberFormatException e) {
                    //
                }
            }
            else {
                stockField.setStyle("-fx-text-inner-color: red;");
            }
        });
    }

    /**
     * Listener to capture input into the Price field.  A double value for the price of the product.
     */
    public void productPriceFieldListener() {
        priceField.setOnKeyReleased(event -> {

            priceField.setStyle("-fx-text-inner-color: black;");

            if(NumberChecker.isDouble(priceField.getText())) {
                try {
                    this.product.setPrice(Double.parseDouble(priceField.getText()));
                }
                catch (NumberFormatException e) {
                    // none needed here.
                }
            }
            else {
                priceField.setStyle("-fx-text-inner-color: red;");
            }
        });
    }

    /**
     * Listener to capture input into the Min field.  An int value for the minimum number to have in stock.
     */
    public void productMinFieldListener() {
        minField.setOnKeyReleased(event -> {

            minField.setStyle("-fx-text-inner-color: black;");

            if(NumberChecker.isInteger(minField.getText())) {
                this.product.setMin(Integer.parseInt(minField.getText()));
            }
            else {
                minField.setStyle("-fx-text-inner-color: red;");
            }
        });
    }

    /**
     * Listener to capture input into the Max field.  An int value for the maximum number to have in stock.
     */
    public void productMaxFieldListener() {
        maxField.setOnKeyReleased(event -> {

            maxField.setStyle("-fx-text-inner-color: black;");

            if(NumberChecker.isInteger(maxField.getText())) {
                this.product.setMax(Integer.parseInt(maxField.getText()));
            }
            else {
                maxField.setStyle("-fx-text-inner-color: red;");
            }
        });
    }

    /**
     * Listener to capture input into the search bar and filter the list accordingly.  If a part ID is entered in to the
     * search bar, that part is selected.  If a string of characters is entered, the parts list is filtered accordingly.
     */
    public void partSearchBarListener() {
        partsSearchField.setOnKeyReleased(event -> {

            String input = partsSearchField.getText();
            boolean isInt = NumberChecker.isInteger(input);

            if(input.length() >= 1 && isInt) {
                // Perform a search of parts based on part ID
                ObservableList<Part> result = FXCollections.observableArrayList();

                try {
                    int idSearch = Integer.parseInt(input);
                    result.add(invCtrl.getInventory().lookupPart(idSearch));
                } catch (IOException e) {
                    //e.printStackTrace();
                }

                partsTable.getSelectionModel().select(result.get(0));

                // partsTable.setItems(result);
            }
            else {
                // Perform a search of parts based on a String
                partsTable.setItems(invCtrl.getInventory().lookupPart(input));
            }
        });
    }

    /**
     * Listener to capture input to the add part button.  Adds the selected part to the associated parts list for the
     * Product object.
     */
    public void addAssociatedPartButtonListener() {
        addAssociatedPartButton.setOnMouseClicked(event -> {

            if(partsTable.getSelectionModel().getSelectedItem() == null) {

            }
            else {
                try {
                    product.addAssociatedPart(partsTable.getSelectionModel().getSelectedItem());
                } catch (Exception e) {
                    //
                }

                associatedPartsTable.setItems(product.getAllAssociatedParts());
            }
        });
    }

    /**
     * Listener to capture input to the remove part button.  Removes the selected part from the associated parts list
     * for the Product object.
     */
    public void removeAssociatedPartButtonListener() {
        removeAssociatedPartButton.setOnMouseClicked(event -> {

            if(associatedPartsTable.getSelectionModel().getSelectedItem() == null) {

            }
            else {
                product.deleteAssociatedPart(associatedPartsTable.getSelectionModel().getSelectedItem());

                associatedPartsTable.setItems(product.getAllAssociatedParts());

                confirmLabel.setText("SUCCESS: Part removed!");
                confirmLabel.setVisible(true);
            }
        });
    }

    /**
     * Listener to capture input to the save button.  Saves all values and associated parts to the Product object and
     * adds the Product to the inventory.  Will not allow the Product to be saved with invalid input in the fields.
     */
    public void saveButtonListener() {
        saveProductButton.setOnMouseClicked(event -> {

            archiveProduct = product;

            boolean save = true;

            Stage stage = (Stage) saveProductButton.getScene().getWindow();

            Inventory inv = invCtrl.getInventory();

            // If all the fields aren't saved, need to stop the save...
            if(nameField.getText().equals("") || stockField.getText().equals("") ||
                    priceField.getText().equals("") || minField.getText().equals("") ||
                    maxField.getText().equals("")) {
                save = false;

                errorMessage.setText("Error: One or more fields are blank!");
                errorMessage.setVisible(true);
            }
            else if(Integer.parseInt(minField.getText()) > Integer.parseInt(maxField.getText())) {
                save = false;

                errorMessage.setText("ERROR: Max value is less than min value!");
                errorMessage.setVisible(true);
            }
            else if(Integer.parseInt(stockField.getText()) < Integer.parseInt(minField.getText()) ||
                    Integer.parseInt(stockField.getText()) > Integer.parseInt(maxField.getText())) {
                save = false;

                errorMessage.setText("ERROR: Stock value is outside bounds of max and min!");
                errorMessage.setVisible(true);
            }
            else if(Integer.parseInt(stockField.getText()) < 0 ||
                    Double.parseDouble(priceField.getText()) < 0 ||
                    Integer.parseInt(minField.getText()) < 0 ||
                    Integer.parseInt(maxField.getText()) < 0) {
                save = false;

                errorMessage.setText("ERROR: Numerical values cannot be negative!");
                errorMessage.setVisible(true);
            }
            else save = NumberChecker.isInteger(stockField.getText()) || NumberChecker.isDouble(priceField.getText()) ||
                    NumberChecker.isInteger(minField.getText()) || NumberChecker.isInteger(maxField.getText());

            if(save) {
                inv.deleteProduct(archiveProduct);

                product.setName(nameField.getText());
                product.setStock(Integer.parseInt(stockField.getText()));
                product.setPrice(Double.parseDouble(priceField.getText()));
                product.setMax(Integer.parseInt(maxField.getText()));
                product.setMin(Integer.parseInt(minField.getText()));
                /*
                for(Part p : associatedPartsTable.getItems()) {
                    try {
                        product.addAssociatedPart(p);
                    } catch (Exception e) {
                        //
                    }
                }
                 */

                inv.addProduct(product);

                invCtrl.load();

                stage.close();
            }
        });
    }

    /**
     * Listener to capture input to the cancel button.
     */
    public void cancelButtonListener() {
        cancelProductButton.setOnMouseClicked(event -> {

            Stage stage = (Stage) cancelProductButton.getScene().getWindow();

            stage.close();

        });
    }
}

