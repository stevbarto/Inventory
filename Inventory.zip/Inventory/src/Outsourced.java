/**
 * Outsourced part class which is a subclass of Part.
 * @author Steven Barton
 */
public class Outsourced extends Part {
    private String companyName;

    /**
     * Outsourced part constructor generates a new Outsourced object.
     * @param id
     * @param name
     * @param price
     * @param stock
     * @param min
     * @param max
     * @param companyName
     */
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }

    /**
     * Assigns a source company name to the outsourced part.
     * @param companyName
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    /**
     * Returns the source company name of the outsourced part.
     * @return
     */
    public String getCompanyName() {
        return this.companyName;
    }
}
