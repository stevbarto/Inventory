/**
 * In house part class which is a subclass of Part.
 * @author Steven Barton
 */
public class InHouse extends Part {
    private int machineId;

    /**
     * In house part constructor generates a new in house part.
     * @param id
     * @param name
     * @param price
     * @param stock
     * @param min
     * @param max
     * @param machineId
     */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId) {
        super(id, name, price, stock, min, max);
        this.machineId = machineId;
    }

    /**
     * Assigns a machine ID to the in house part.
     * @param machineId
     */
    public void setMachineId(int machineId) {
        this.machineId = machineId;
    }

    /**
     * Returns the machine id for the in house part.
     * @return
     */
    public int getMachineId() {
        return this.machineId;
    }

 }
