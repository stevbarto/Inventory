import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Add Product controller class, provides functionality to the add product window.  Creates a new Product object and
 * populates all object variables with data.  Will not allow a product to be saved with invalid input into the required
 * fields.
 * @author Steven Barton
 */
public class AddProductController {

    InventoryController invCtrl;

    Inventory inventory;

    ObservableList<Part> associatedParts;

    Product product;

    String name;
    int stock;
    double price;
    int min;
    int max;

    @FXML
    private Label addProductLabel;

    @FXML
    private Label idLabel;

    @FXML
    private Label nameLabel;

    @FXML
    private Label inventoryLabel;

    @FXML
    private Label priceLabel;

    @FXML
    private Label maxLabel;

    @FXML
    private Label minLabel;

    @FXML
    private TextField productIdField;

    @FXML
    private TextField productNameField;

    @FXML
    private TextField productInventoryField;

    @FXML
    private TextField productPriceField;

    @FXML
    private TextField productMaxField;

    @FXML
    private TextField productMinField;

    @FXML
    private TextField partSearchBar;

    @FXML
    private TableView<Part> partsTable;

    @FXML
    private TableColumn<Part, Integer> partIdColumn;

    @FXML
    private TableColumn<Part, String> partNameColumn;

    @FXML
    private TableColumn<Part, Integer> partInventoryColumn;

    @FXML
    private TableColumn<Part, Double> partPriceColumn;

    @FXML
    private Button addAssociatedPartButton;

    @FXML
    private Button removeAssociatedPartButton;

    @FXML
    private Button saveProductButton;

    @FXML
    private Button cancelProductButton;

    @FXML
    private TableView<Part> associatedPartsTable;

    @FXML
    private TableColumn<Part, Integer> partIdColumn1;

    @FXML
    private TableColumn<Part, String> partNameColumn1;

    @FXML
    private TableColumn<Part, Integer> partInventoryColumn1;

    @FXML
    private TableColumn<Part, Double> partCostColumn1;

    @FXML
    private Label errorMessage;

    @FXML
    private Label confirmLabel;

    /**
     * Method to initialize the AddProductController instance.  Adds listeners to all controllers and populates all
     * object fields with initial values.
     */
    public void initialize() {

        productNameField.setOnAction(e -> productNameFieldListener());

        productInventoryField.setOnAction(e -> productStockFieldListener());

        productPriceField.setOnAction(e -> productPriceFieldListener());

        productMaxField.setOnAction(e -> productMaxFieldListener());

        productMinField.setOnAction(e -> productMinFieldListener());

        partSearchBar.setOnAction(e -> partSearchBarListener());

        addAssociatedPartButton.setOnAction(e -> partAddButtonListener());

        removeAssociatedPartButton.setOnAction(e -> partRemoveButtonListener());

        saveProductButton.setOnAction(e -> saveButtonListener());

        cancelProductButton.setOnAction(e -> cancelButtonListener());

        partIdColumn.setCellValueFactory(new PropertyValueFactory<Part, Integer>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
        partInventoryColumn.setCellValueFactory(new PropertyValueFactory<Part, Integer>("stock"));
        partPriceColumn.setCellValueFactory(new PropertyValueFactory<Part, Double>("price"));

        partIdColumn1.setCellValueFactory(new PropertyValueFactory<Part, Integer>("id"));
        partNameColumn1.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
        partInventoryColumn1.setCellValueFactory(new PropertyValueFactory<Part, Integer>("stock"));
        partCostColumn1.setCellValueFactory(new PropertyValueFactory<Part, Double>("price"));

        name = "Set Name";
        stock = -1;
        price = 1.00;
        min = -1;
        max = -1;
        associatedParts = FXCollections.observableArrayList();


    }

    /**
     * Sets the parent InventoryController instance for this AddProductController.
     * @param inventoryController InventoryController instance used to initiate this AddProductController.
     */
    public void getInventoryController(InventoryController inventoryController) {

        this.invCtrl = inventoryController;
    }

    /**
     * Sets the items to display in the  master parts menu for the add product window.
     * @param inv Inventory instance containing the parts list.
     */
    public void setItems(Inventory inv) {

        partsTable.setItems(inv.getAllParts());
    }

    /**
     * Sets the inventory used for this add product window.
     * @param items Invenotry instance supporting this window.
     */
    public void setInventory(Inventory items) {

        inventory = items;
    }

    /**
     * Listener to capture input into the name field.  Saves a String object with valid letters, digits, and characters.
     */
    public void productNameFieldListener() {
        productNameField.setOnKeyReleased(event -> {

            errorMessage.setVisible(false);
            confirmLabel.setVisible(false);

            this.name = productNameField.getText();
        });
    }

    /**
     * Listener to capture input into the stock field.  Saves an int value for the number of Products in stock.
     */
    public void productStockFieldListener() {
        productInventoryField.setOnKeyReleased(event -> {

            errorMessage.setVisible(false);
            confirmLabel.setVisible(false);

            productInventoryField.setStyle("-fx-text-inner-color: black;");

            if(NumberChecker.isInteger(productInventoryField.getText())) {
                try {
                    this.stock = Integer.parseInt(productInventoryField.getText());
                }
                catch (NumberFormatException e) {
                    //
                }
            }
            else {
                productInventoryField.setStyle("-fx-text-inner-color: red;");
            }
        });
    }

    /**
     * Listener to capture input into the price field.  Saves a double value for the price of the Product.
     */
    public void productPriceFieldListener() {
        productPriceField.setOnKeyReleased(event -> {

            errorMessage.setVisible(false);
            confirmLabel.setVisible(false);

            productPriceField.setStyle("-fx-text-inner-color: black;");

            if(NumberChecker.isDouble(productPriceField.getText())) {
                try {
                    this.price = Double.parseDouble(productPriceField.getText());
                }
                catch (NumberFormatException e) {
                    // none needed here.
                }
            }
            else {
                productPriceField.setStyle("-fx-text-inner-color: red;");
            }
        });
    }

    /**
     * Listener to capture input into the max field.  Saves an int value for the maximum Products in stock.
     */
    public void productMaxFieldListener() {
        productMaxField.setOnKeyReleased(event -> {

            errorMessage.setVisible(false);
            confirmLabel.setVisible(false);

            productMaxField.setStyle("-fx-text-inner-color: black;");

            if(NumberChecker.isInteger(productMaxField.getText())) {
                this.max = Integer.parseInt(productMaxField.getText());
            }
            else {
                productMaxField.setStyle("-fx-text-inner-color: red;");
            }
        });
    }

    /**
     * Listener to capture input into the min field.  Saves an int value for the min number of Products in stock.
     */
    public void productMinFieldListener() {
        productMinField.setOnKeyReleased(event -> {

            errorMessage.setVisible(false);
            confirmLabel.setVisible(false);

            productMinField.setStyle("-fx-text-inner-color: black;");

            if(NumberChecker.isInteger(productMinField.getText())) {
                this.min = Integer.parseInt(productMinField.getText());
            }
            else {
                productMinField.setStyle("-fx-text-inner-color: red;");
            }
        });
    }

    /**
     * Listener to capture input into the parts search bar.  When an integer is input corresponding to a product ID, the
     * part with the corresponding ID is highlighted.  When a string of characters is input that does not correspond to
     * a part ID is input, the parts list is filtered by the string used in the search.
     */
    public void partSearchBarListener() {
        partSearchBar.setOnKeyReleased(event -> {

            errorMessage.setVisible(false);
            confirmLabel.setVisible(false);

            String input = partSearchBar.getText();
            boolean isInt = NumberChecker.isInteger(input);

            if(input.length() >= 1 && isInt) {
                // Perform a search of parts based on part ID
                ObservableList<Part> result = FXCollections.observableArrayList();

                try {
                    int idSearch = Integer.parseInt(input);
                    result.add(invCtrl.getInventory().lookupPart(idSearch));
                } catch (IOException e) {
                    //e.printStackTrace();
                }

                partsTable.getSelectionModel().select(result.get(0));

                // partsTable.setItems(result);
            }
            else {
                // Perform a search of parts based on a String
                partsTable.setItems(invCtrl.getInventory().lookupPart(input));
            }
        });
    }

    /**
     * Listener to capture input into the add parts button.
     */
    public void partAddButtonListener() {
        addAssociatedPartButton.setOnMouseClicked(event -> {

            errorMessage.setVisible(false);
            confirmLabel.setVisible(false);

            if(partsTable.getSelectionModel().getSelectedItem() == null) {

            }
            else {
                associatedParts.add(partsTable.getSelectionModel().getSelectedItem());

                associatedPartsTable.setItems(associatedParts);
            }
        });
    }

    /**
     * Listener to capture input into the remove parts button.
     */
    public void partRemoveButtonListener() {
        removeAssociatedPartButton.setOnMouseClicked(event -> {

            errorMessage.setVisible(false);
            confirmLabel.setVisible(false);

            if(associatedPartsTable.getSelectionModel().getSelectedItem() == null) {
                // Do Nothing?
            }
            else {
                associatedParts.remove(associatedPartsTable.getSelectionModel().getSelectedItem());

                associatedPartsTable.setItems(associatedParts);

                confirmLabel.setText("SUCCESS: Part removed!");
                confirmLabel.setVisible(true);
            }
        });
    }

    /**
     * Listener to caputre input into the save button.  Saves all input values into the new part object, adds all added
     * parts to the associated parts list for the new Product object.  Will not allow the Product to be saved with
     * invalid input in the fields.
     */
    public void saveButtonListener() {
        saveProductButton.setOnMouseClicked(event -> {

            errorMessage.setVisible(false);
            confirmLabel.setVisible(false);

            boolean save = true;

            Stage stage = (Stage) saveProductButton.getScene().getWindow();

            Inventory inv = invCtrl.getInventory();

            // If all the fields aren't saved, need to stop the save...
            if(productNameField.getText().equals("") || productInventoryField.getText().equals("") ||
                    productPriceField.getText().equals("") || productMinField.getText().equals("") ||
                    productMaxField.getText().equals("")) {
                save = false;

                errorMessage.setText("Error: One or more fields are blank!");
                errorMessage.setVisible(true);
            }
            else if(Integer.parseInt(productMinField.getText()) > Integer.parseInt(productMaxField.getText())) {
                save = false;

                errorMessage.setText("ERROR: Max value is less than min value!");
                errorMessage.setVisible(true);
            }
            else if(Integer.parseInt(productInventoryField.getText()) < Integer.parseInt(productMinField.getText()) ||
                    Integer.parseInt(productInventoryField.getText()) > Integer.parseInt(productMaxField.getText())) {
                save = false;

                errorMessage.setText("ERROR: Stock value is outside bounds of max and min!");
                errorMessage.setVisible(true);
            }
            else if(Integer.parseInt(productInventoryField.getText()) < 0 ||
                    Double.parseDouble(productPriceField.getText()) < 0 ||
                    Integer.parseInt(productMinField.getText()) < 0 ||
                    Integer.parseInt(productMaxField.getText()) < 0) {
                save = false;

                errorMessage.setText("ERROR: Numerical values cannot be negative!");
                errorMessage.setVisible(true);
            }
            else save = NumberChecker.isInteger(productInventoryField.getText()) || NumberChecker.isDouble(productPriceField.getText()) ||
                        NumberChecker.isInteger(productMinField.getText()) || NumberChecker.isInteger(productMaxField.getText());


            if(save) {

                int productId = inv.getProdIdNum();

                // Need to save all variables to a new part object...
                product = new Product(productId, name, price, stock, min, max);

                while(product.getName() == "Set Name" || product.getPrice() == -1.00 || product.getStock() == -1
                || product.getMin() == -1 || product.getMax() == -1) {
                    product.setName(productNameField.getText());
                    product.setPrice(Double.parseDouble(productPriceField.getText()));
                    product.setStock(Integer.parseInt(productInventoryField.getText()));
                    product.setMin(Integer.parseInt(productMinField.getText()));
                    product.setMax(Integer.parseInt(productMaxField.getText()));
                }

                for(Part p : associatedParts) {
                    try {
                        product.addAssociatedPart(p);
                    } catch (Exception e) {
                        // Do nothing.
                    }
                }

                inv.addProduct(product);

                invCtrl.load();

                stage.close();
            }
        });
    }

    /**
     * Listener to capture input into the cancel button.
     */
    public void cancelButtonListener() {
        cancelProductButton.setOnMouseClicked(event -> {

            errorMessage.setVisible(false);
            confirmLabel.setVisible(false);

            Stage stage = (Stage) cancelProductButton.getScene().getWindow();

            stage.close();

        });
    }

}

