import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/**
 * Modify Part controller class, adds functionality to the modify part window.  Imports an InHouse or Outsourced object
 * to modify.
 * @author Steven Barton
 */
public class ModifyPartController {

    String name;
    int stock;
    double price;
    int max;
    int min;
    String companyName;
    int machineId;

    InventoryController invCtrl;

    Part part;
    Part archivePart;

    boolean save;

    boolean isInHouse;

    @FXML
    private Label addPartLabel;

    @FXML
    private TextField idTextField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField stockField;

    @FXML
    private TextField priceField;

    @FXML
    private TextField minField;

    @FXML
    private Label idLabel;

    @FXML
    private Label nameLabel;

    @FXML
    private Label stockLabel;

    @FXML
    private Label priceLabel;

    @FXML
    private Label minLabel;

    @FXML
    private Label maxLabel;

    @FXML
    private TextField maxField;

    @FXML
    private RadioButton inHouseRadioButton;

    @FXML
    private ToggleGroup partType;

    @FXML
    private RadioButton outSourcedRadioButton;

    @FXML
    private TextField variableField;

    @FXML
    private Label variableLabel;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    @FXML
    private Label errorMessage;

    /**
     * Method to initialize the controller for the modify part window.  Sets initial values and listeners.
     */
    public void initialize() {

        save = true;

        nameField.setOnAction(e -> nameFieldListener());

        stockField.setOnAction(e -> stockFieldListener());

        priceField.setOnAction(e -> priceFieldListener());

        minField.setOnAction(e -> minFieldListener());

        maxField.setOnAction(e -> maxFieldListener());

        variableField.setOnKeyReleased(e -> variableFieldListener());

        saveButton.setOnAction(e -> saveButtonListener());

        cancelButton.setOnAction(e -> cancelButtonListener());

        inHouseRadioButton.setOnAction(e -> inHouseRadioButtonListener());

        outSourcedRadioButton.setOnAction(e -> outSourcedRadioButtonListener());

        archivePart = part;

        if (part instanceof InHouse) {
            inHouseRadioButton.setSelected(true);
            InHouse inHouse = (InHouse) part;
            isInHouse = true;
            variableField.setText(inHouse.getMachineId() + "");
        } else {
            outSourcedRadioButton.setSelected(true);
            Outsourced outsourced = (Outsourced) part;
            isInHouse = false;
            variableLabel.setText("Company Name");
            variableField.setText(outsourced.getCompanyName());
        }

        idTextField.setText(Integer.toString(part.getId()));

        nameField.setText(part.getName());

        stockField.setText(Integer.toString(part.getStock()));

        priceField.setText(Double.toString(part.getPrice()));

        minField.setText(Integer.toString(part.getMin()));

        maxField.setText(Integer.toString(part.getMax()));

        // Need to get inhouse/outsourced value and handle button selection and text accordingly
    }

    /**
     * Method to pull the InventoryController instance from the launch method in that controller.
     * @param c InventoryController instance to be assigned to this ModifyPartController.
     */
    public void setInventoryController(InventoryController c) {
        this.invCtrl = c;
    }

    /**
     * Method to pull the selected part that is being modified by this controller instance.
     * @param p Selected Part object.
     */
    public void setPart(Part p) {
        this.part = p;
    }

    /**
     * Listener to capture mouse input for the save button, saves the current changes to the selected
     * Part object.  Will not allow the part to be saved with invalid values in the fields.
     */
    public void saveButtonListener() {

        Stage stage = (Stage) saveButton.getScene().getWindow();

        Inventory inv = invCtrl.getInventory();

        // If all the fields aren't saved, need to stop the save...
        if (nameField.getText().equals("") || stockField.getText().equals("") ||
                priceField.getText().equals("") || minField.getText().equals("") ||
                maxField.getText().equals("") || variableField.getText().equals("")) {
            // Should have a message display when fields are blank...
            save = false;

            errorMessage.setText("ERROR: One or more required fields are blank!");
            errorMessage.setVisible(true);
        }
        else if(Integer.parseInt(minField.getText()) > Integer.parseInt(maxField.getText())) {
            save = false;

            errorMessage.setText("ERROR: Max value is less than min value!");
            errorMessage.setVisible(true);
        }
        else if(Integer.parseInt(stockField.getText()) < Integer.parseInt(minField.getText()) ||
                Integer.parseInt(stockField.getText()) > Integer.parseInt(maxField.getText())) {
            save = false;

            errorMessage.setText("ERROR: Stock value is outside bounds of max and min!");
            errorMessage.setVisible(true);
        }
        else if(Integer.parseInt(stockField.getText()) < 0 ||
                Double.parseDouble(priceField.getText()) < 0 ||
                Integer.parseInt(minField.getText()) < 0 ||
                Integer.parseInt(maxField.getText()) < 0) {
            save = false;

            errorMessage.setText("ERROR: Numerical values cannot be negative!");
            errorMessage.setVisible(true);
        }
        else save = NumberChecker.isInteger(stockField.getText()) && NumberChecker.isDouble(priceField.getText()) &&
                NumberChecker.isInteger(minField.getText()) && NumberChecker.isInteger(maxField.getText());

        if (save) {

            inv.deletePart(archivePart);

            if(isInHouse) {
                if(archivePart instanceof Outsourced) {
                    part = new InHouse(archivePart.getId(), nameField.getText(), Double.parseDouble(priceField.getText()),
                            Integer.parseInt(stockField.getText()), Integer.parseInt(minField.getText()), Integer.parseInt(maxField.getText()),
                            machineId);
                }
                else {
                    part.setName(nameField.getText());
                    part.setPrice(Double.parseDouble(priceField.getText()));
                    part.setStock(Integer.parseInt(stockField.getText()));
                    part.setMin(Integer.parseInt(minField.getText()));
                    part.setMax(Integer.parseInt(maxField.getText()));
                    ((InHouse) part).setMachineId(Integer.parseInt(variableField.getText()));
                }
            }
            else {
                if (archivePart instanceof InHouse) {
                    part = new Outsourced(archivePart.getId(), nameField.getText(), Double.parseDouble(priceField.getText()),
                            Integer.parseInt(stockField.getText()), Integer.parseInt(minField.getText()), Integer.parseInt(maxField.getText()),
                            companyName);
                } else {
                    part.setName(nameField.getText());
                    part.setPrice(Double.parseDouble(priceField.getText()));
                    part.setStock(Integer.parseInt(stockField.getText()));
                    part.setMin(Integer.parseInt(minField.getText()));
                    part.setMax(Integer.parseInt(maxField.getText()));
                    ((Outsourced) part).setCompanyName(variableField.getText());
                }
            }

            inv.addPart(part);

            invCtrl.load();

            stage.close();
        }

    }

    /**
     * Captures mouse input to the cancel button, closes the window without saving.
     */
    public void cancelButtonListener() {

        Stage stage = (Stage) cancelButton.getScene().getWindow();

        stage.close();

    }

    /**
     * Captures mouse input to the in house radio button.
     */
    public void inHouseRadioButtonListener() {
        variableLabel.setText("Machine ID");
        isInHouse = true;
    }

    /**
     * Captures mouse input to the outsourced radio button.
     */
    public void outSourcedRadioButtonListener() {
        variableLabel.setText("Company Name");
        isInHouse = false;
    }

    /**
     * Actively captures and stores key input to the Name field.  A String value is saved for the part name.
     */
    public void nameFieldListener() {
        this.name = nameField.getText();
        //part.setName(name);
    }

    /**
     * Actively captures and stores input to the price field.  A double value is saved for the part price.
     */
    public void priceFieldListener() {
        priceField.setStyle("-fx-text-inner-color: black;");

        if(NumberChecker.isDouble(priceField.getText())) {
            try {
                this.price = Double.parseDouble(priceField.getText());
            }
            catch (NumberFormatException e) {
                // none needed here.
            }
        }
        else {
            priceField.setStyle("-fx-text-inner-color: red;");
        }

    }

    /**
     * Actively captures and stores key input to the stock field.  An int value is saved for the current stock on hand.
     */
    public void stockFieldListener() {
        stockField.setStyle("-fx-text-inner-color: black;");

        if(NumberChecker.isInteger(stockField.getText())) {
            try {
                this.stock = Integer.parseInt(stockField.getText());
            }
            catch (NumberFormatException e) {
                //
            }
        }
        else {
            stockField.setStyle("-fx-text-inner-color: red;");
        }
    }

    /**
     * Actively captures and stores key input to the min field.  An int value is saved for the minimum to have in stock.
     */
    public void minFieldListener() {
        minField.setStyle("-fx-text-inner-color: black;");

        if(NumberChecker.isInteger(minField.getText())) {
            this.min = Integer.parseInt(minField.getText());
        }
        else {
            minField.setStyle("-fx-text-inner-color: red;");
        }
    }

    /**
     * Actively captures and stores key input to the max field.  An int value is saved for the maximum number in stock.
     */
    public void maxFieldListener() {
        maxField.setStyle("-fx-text-inner-color: black;");

        if(NumberChecker.isInteger(maxField.getText())) {
            this.max = Integer.parseInt(maxField.getText());
        }
        else {
            maxField.setStyle("-fx-text-inner-color: red;");
        }
    }

    /**
     * Actively captures and stores input to the variable field based on the selected value of the
     * in house and outsourced radio buttons.  If in house is selected, the machine ID is stored.  If
     * outsourced is selected the company name is stored.
     */
    public void variableFieldListener() {

        maxField.setStyle("-fx-text-inner-color: black;");

        if(isInHouse) {

            String input = variableField.getText();

            if(NumberChecker.isInteger(input)) {
                maxField.setStyle("-fx-text-inner-color: black;");
                machineId = Integer.parseInt(variableField.getText());
            }
            else {
                variableField.setStyle("-fx-text-inner-color: red;");
            }
        }
        else {
            maxField.setStyle("-fx-text-inner-color: black;");
            companyName = variableField.getText();
        }
    }

}
