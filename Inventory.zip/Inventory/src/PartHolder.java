public final class PartHolder {

    private Part part;
    private final static PartHolder INSTANCE = new PartHolder();

    private PartHolder() {}

    public static PartHolder getInstance() {
        return INSTANCE;
    }

    public void setPart(Part p) {
        this.part = p;
    }

    public Part getPart() {
        return this.part;
    }
}
