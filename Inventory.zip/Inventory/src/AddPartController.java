import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/**
 * Add Part controller class, provides functionality to the add part window.  Creates a new InHouse or Outsourced object
 * and populates all data fields for the objects.  Imports a InventoryController object to facilitate saving the object
 * to the inventory.  Will not save a part without all required data fields input.
 * @author Steven Barton
 */
public class AddPartController {

    Part part;
    int id;
    String name;
    int stock;
    double price;
    int min;
    int max;
    int machineId;
    String companyName;

    boolean inHouse;

    InventoryController invCtrl;


    @FXML
    private Label addPartLabel;

    @FXML
    private TextField idTextField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField stockField;

    @FXML
    private TextField priceField;

    @FXML
    private TextField minField;

    @FXML
    private Label idLabel;

    @FXML
    private Label nameLabel;

    @FXML
    private Label stockLabel;

    @FXML
    private Label priceLabel;

    @FXML
    private Label minLabel;

    @FXML
    private Label maxLabel;

    @FXML
    private TextField maxField;

    @FXML
    private RadioButton inHouseRadioButton;

    @FXML
    private ToggleGroup partType;

    @FXML
    private RadioButton outSourcedRadioButton;

    @FXML
    private TextField variableField;

    @FXML
    private Label variableLabel;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    @FXML
    private Label errorMessage;

    /**
     * Initialize method for the AddPartController object. Populates initial values for part data variables.
     */
    public void initialize() {
        inHouse = true;

        id = -1;
        name = "Set Name";
        stock = -1;
        price = -1.00;
        min = -1;
        max = -1;
        machineId = -1;
        companyName = "-1";


    }

    /**
     * Listener to capture input to the in house radio button.
     */
    public void inHouseRadioButtonListener() {

        inHouseRadioButton.setOnMouseClicked(event -> {
            variableLabel.setText("Machine ID");
            inHouse = true;
        });
    }

    /**
     * Listener to capture input to the outsourced radio button.
     */
    public void outSourcedRadioButtonListener() {

        outSourcedRadioButton.setOnMouseClicked(event -> {
            variableLabel.setText("Company Name");
            inHouse = false;
        });
    }

    /**
     * Listener to capture input to the save button. Checks save conditions to ensure invalid input is not saved to the
     * inventory.  Saves the new object as either an InHouse or Outsourced object according to the option selected.
     */
    public void saveButtonListener() {
        saveButton.setOnMouseClicked(event -> {

            errorMessage.setVisible(false);

            boolean save = true;

            Stage stage = (Stage) saveButton.getScene().getWindow();

            Inventory inv = invCtrl.getInventory();

            // If all the fields aren't saved, need to stop the save...
            if(nameField.getText().equals("") || stockField.getText().equals("") ||
            priceField.getText().equals("") || minField.getText().equals("") ||
            maxField.getText().equals("") || variableField.getText().equals("")) {
                save = false;

                errorMessage.setText("ERROR: One or more required fields are blank!");
                errorMessage.setVisible(true);
            }
            else if(Integer.parseInt(minField.getText()) > Integer.parseInt(maxField.getText())) {
                save = false;

                errorMessage.setText("ERROR: Max value is less than min value!");
                errorMessage.setVisible(true);
            }
            else if(Integer.parseInt(stockField.getText()) < Integer.parseInt(minField.getText()) ||
                    Integer.parseInt(stockField.getText()) > Integer.parseInt(maxField.getText())) {
                save = false;

                errorMessage.setText("ERROR: Stock value is outside bounds of max and min!");
                errorMessage.setVisible(true);
            }
            else if(Integer.parseInt(stockField.getText()) < 0 ||
                    Double.parseDouble(priceField.getText()) < 0 ||
                    Integer.parseInt(minField.getText()) < 0 ||
                    Integer.parseInt(maxField.getText()) < 0) {
                save = false;

                errorMessage.setText("ERROR: Numerical values cannot be negative!");
                errorMessage.setVisible(true);
            }
            else save = NumberChecker.isInteger(stockField.getText()) && NumberChecker.isDouble(priceField.getText()) &&
                        NumberChecker.isInteger(minField.getText()) && NumberChecker.isInteger(maxField.getText());

            if(save) {

                int partId = inv.getPartIdNum();

                // Need to save all variables to a new part object...
                if (inHouse) {
                    machineId = Integer.parseInt(variableField.getText());

                    part = new InHouse(partId, name, price, stock, min, max, machineId);

                    while(part.getName().equals("Set Name") || part.getStock() == -1 ||
                            part.getPrice() == -1.00 || part.getMin() == -1 ||
                            part.getMax() == -1) {

                        part.setName(nameField.getText());
                        part.setStock(Integer.parseInt(stockField.getText()));
                        part.setPrice(Double.parseDouble(priceField.getText()));
                        part.setMin(Integer.parseInt(minField.getText()));
                        part.setMax(Integer.parseInt(maxField.getText()));
                        // Machine ID?
                    }

                } else {
                    companyName = variableField.getText();

                    part = new Outsourced(partId, name, price, stock, min, max, companyName);

                    while(part.getName().equals("Set Name") || part.getStock() == -1 ||
                            part.getPrice() == -1.00 || part.getMin() == -1 ||
                            part.getMax() == -1) {

                        part.setName(nameField.getText());
                        part.setStock(Integer.parseInt(stockField.getText()));
                        part.setPrice(Double.parseDouble(priceField.getText()));
                        part.setMin(Integer.parseInt(minField.getText()));
                        part.setMax(Integer.parseInt(maxField.getText()));
                        // Company name?
                    }

                }

                // Need to add the part object to the inventory from this controller...
                inv.addPart(part);

                invCtrl.load();

                stage.close();
            }
        });
    }

    /**
     * Listener to capture input to the cancel button.
     */
    public void cancelButtonListener() {
        cancelButton.setOnMouseClicked(event -> {

            Stage stage = (Stage) cancelButton.getScene().getWindow();

            stage.close();

        });
    }

    /**
     * Listener to capture input to the name field.  Saves as a String object of valid letters, digits, and characters.
     */
    public void nameFieldListener() {
        nameField.setOnKeyReleased(event -> {
            this.name = nameField.getText();
        });
    }

    /**
     * Listener to capture input to the stock field.  Saves an int value of the number of parts in stock.
     */
    public void stockFieldListener() {
        stockField.setOnKeyReleased(event -> {

            stockField.setStyle("-fx-text-inner-color: black;");

            if(NumberChecker.isInteger(stockField.getText())) {
                try {
                    this.stock = Integer.parseInt(stockField.getText());
                }
                catch (NumberFormatException e) {
                    //
                }
            }
            else {
                stockField.setStyle("-fx-text-inner-color: red;");
            }
        });
    }

    /**
     * Listener to capture input into the price field.  Saves a double value of the price for the part.
     */
    public void priceFieldListener() {
        priceField.setOnKeyReleased(event -> {

            priceField.setStyle("-fx-text-inner-color: black;");

            if(NumberChecker.isDouble(priceField.getText())) {
                try {
                    this.price = Double.parseDouble(priceField.getText());
                }
                catch (NumberFormatException e) {
                    // none needed here.
                }
            }
            else {
                priceField.setStyle("-fx-text-inner-color: red;");
            }

        });
    }

    /**
     * Listener to capture input into the min field.  Saves an int value of the minimum stock to keep on hand.
     */
    public void minFieldListener() {
        minField.setOnKeyReleased(event -> {

            minField.setStyle("-fx-text-inner-color: black;");

            if(NumberChecker.isInteger(minField.getText())) {
                this.min = Integer.parseInt(minField.getText());
            }
            else {
                minField.setStyle("-fx-text-inner-color: red;");
            }
        });
    }

    /**
     * Listener to capture input into the max field.  Saves an int value of the maximum stock to keep on hand.
     */
    public void maxFieldListener() {
        maxField.setOnKeyReleased(event -> {

            maxField.setStyle("-fx-text-inner-color: black;");

            if(NumberChecker.isInteger(maxField.getText())) {
                this.max = Integer.parseInt(maxField.getText());
            }
            else {
                maxField.setStyle("-fx-text-inner-color: red;");
            }
        });
    }

    /**
     * Listner to capture input in to the varible field.  Captures machine ID if the in house
     * radio button is selected.  Captures company name if the outsourced radio button is selected.
     */
    public void variableFieldListener() {
        variableField.setOnKeyReleased(event -> {
            if(inHouse) {
                maxField.setStyle("-fx-text-inner-color: black;");

                String input = variableField.getText();

                if(NumberChecker.isInteger(input)) {
                    machineId = Integer.parseInt(variableField.getText());
                }
                else {
                    variableField.setStyle("-fx-text-inner-color: red;");
                }
            }
            else {
                companyName = variableField.getText();
            }
        });
    }

    /**
     * Public method to get the parent InventoryController class.
     * @param invCtrl InventoryController instance passed from the parent controller.
     */
    public void getInventoryController(InventoryController invCtrl) {
        this.invCtrl = invCtrl;
    }
}
